package com.powersolutions.acdc

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun openUrl(url: String) {
            runOnUiThread {
                try {
                    val uri = Uri.parse(url)
                    if (uri.scheme == "https" && (uri.host == "wa.me" || uri.host == "www.whatsapp.com")) {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    } else {
                        Toast.makeText(this@MainActivity, "Only WhatsApp order links can be opened here.", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Could not open WhatsApp. Please try again.", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun shareText(title: String, body: String) {
            runOnUiThread {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, title)
                    putExtra(Intent.EXTRA_TEXT, body)
                }
                startActivity(Intent.createChooser(send, "Share business document"))
            }
        }

        @JavascriptInterface
        fun shareDocumentImage() {
            runOnUiThread {
                webView.postDelayed({
                    try {
                        val originalHeight = webView.height
                        val contentHeight = (webView.contentHeight * webView.scale).toInt().coerceAtLeast(originalHeight).coerceAtMost(12000)
                        val bitmap = Bitmap.createBitmap(webView.width.coerceAtLeast(1), contentHeight, Bitmap.Config.ARGB_8888)
                        val canvas = Canvas(bitmap)
                        webView.draw(canvas)
                        val images = File(cacheDir, "shared_documents").apply { mkdirs() }
                        val output = File(images, "Power_Solutions_Document.png")
                        FileOutputStream(output).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                        bitmap.recycle()
                        val uri: Uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.provider", output)
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "image/png"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        startActivity(Intent.createChooser(send, "Share business document image"))
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "Could not create document image. Use Print / Save PDF instead.", Toast.LENGTH_LONG).show()
                    } finally {
                        webView.evaluateJavascript("document.body.classList.remove('image-export-mode')", null)
                    }
                }, 300)
            }
        }

        @JavascriptInterface
        fun printDocument() {
            runOnUiThread {
                val printManager = getSystemService(PRINT_SERVICE) as PrintManager
                val adapter = webView.createPrintDocumentAdapter("Power_Solutions_Document")
                printManager.print(
                    "Power Solutions AC & DC",
                    adapter,
                    PrintAttributes.Builder().build()
                )
            }
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }
}
