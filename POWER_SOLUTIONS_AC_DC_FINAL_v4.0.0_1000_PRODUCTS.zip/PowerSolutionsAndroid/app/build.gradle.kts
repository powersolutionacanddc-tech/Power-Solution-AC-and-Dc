plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.powersolutions.acdc"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.powersolutions.acdc"
        minSdk = 23
        targetSdk = 35
        versionCode = 4
        versionName = "4.0.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}


dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}
