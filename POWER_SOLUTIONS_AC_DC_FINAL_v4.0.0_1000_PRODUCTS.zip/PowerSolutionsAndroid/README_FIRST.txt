POWER SOLUTIONS AC & DC — ANDROID SOURCE PROJECT
VERSION 4.1.0 — 1,000-ENTRY SOLAR & ELECTRICAL CATALOGUE

WHAT IS INCLUDED
- Android Kotlin + WebView project and GitHub Actions APK build workflow.
- Original POWER SOLUTIONS AC & DC company banner retained in the app and document header. It appears on every app screen and printed/shared quotation, invoice and receipt.
- Branded quotation, invoice and receipt creation with customer details, item lines, separate transport, VAT, paid amount and balance. The document footer includes the Manufacturer battery warranty contact section.
- Save, reopen, edit and delete documents; activity log; draft autosave; payment receipt from an invoice.
- Share document as text or image, Android share chooser, and Android Print / Save as PDF.
- 1,000 starter product listings across solar and electrical categories; customer online store, cart, WhatsApp enquiry/order flow.
- Management-only screens separated from customer store by a role selector and local PIN screen lock.
- USD pricing with fixed 20% markup on confirmed supplier cost. ZiG selling price formula: USD selling price × management-configured ZiG/USD rate × 1.50.
- Management-only supplier costs and markup; no stock quantities or stock tracking.
- Exact product/model photo policy: starter catalogue representative photos are cleared. Add only a unique, verified exact brand/model image; otherwise a missing-photo note is shown.
- Local backup export/restore.

IMPORTANT LIMITATIONS
- This is a SOURCE PROJECT ZIP, not a prebuilt APK. GitHub Actions must compile the APK.
- Management PIN is a basic on-device UI gate only. It is not secure authentication or encrypted role separation; a technically capable person with device/file access may inspect local app data. Do not use this version as a secure multi-user system.
- All documents, catalogue changes, orders and logs are stored locally on this phone. They do not sync to another device or cloud service. Back up regularly; uninstalling or clearing app storage can erase records.
- The 1,000 entries are starter catalogue options, not verified supplier SKUs or live inventory. Prices remain Price on request until management enters confirmed costs. ZiG prices remain pending until a current exchange rate is entered.
- Exact unique product images have NOT been populated for all 1,000 listings. They are intentionally left blank rather than showing inaccurate or reused images. Management must add verified exact-model images and confirm image-use rights.
- No payment gateway, bank integration, Ecocash/card integration, public e-commerce backend or cloud synchronization is included. Online orders are sent to WhatsApp and remain pending until manually confirmed.
- Transport is a separate line from item subtotal and is included in grand total only when entered. Record it separately where applicable, including online-paid transactions where delivery/transport applies.
- This build workflow creates a DEBUG APK for testing. Google Play, Huawei AppGallery and other stores require a signed release APK/AAB, developer accounts, store listings, policy compliance and review. Uploading this ZIP does not publish the app to those stores.

BUILD FROM YOUR ANDROID PHONE
1. Extract this ZIP.
2. Upload the CONTENTS of the PowerSolutionsAndroid folder into the root of your GitHub repository (including the .github folder).
3. Open GitHub repository → Actions → Build POWER SOLUTIONS AC & DC APK.
4. Run workflow or push a commit to main; wait for a green successful run.
5. Download artifact Power-Solutions-AC-DC-APK, extract it and install app-debug.apk.
6. If the workflow fails, send the red error screen/log for correction.

COMPANY DETAILS
POWER SOLUTIONS AC & DC
12 Tilbury Road, Willowvale, Harare
Main WhatsApp: 0779331564
Online orders: 0784981579 (Mike Dube)
Additional WhatsApp: 0771340158 (Petros Dube)
Calls: 0773955255 | Calls only: 0714472898
Manufacturer battery warranty: WhatsApp 0771340158 | Calls 0773955255
First Capital Bank · Gokwe Branch · Account name Simon Dube · Account 52001557453

MANAGEMENT
Simon Dube — Chief Executive Officer
Petros Dube — Deputy Chief Executive Officer
Mike Dube — Technical, Operations & Finance Manager; Electrical & Solar Systems Designer; Senior Technical Personnel; Operations and Accounts Administration
