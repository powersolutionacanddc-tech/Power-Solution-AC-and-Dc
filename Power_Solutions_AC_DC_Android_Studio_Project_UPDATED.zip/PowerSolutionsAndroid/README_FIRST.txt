POWER SOLUTIONS AC & DC — ANDROID APP PROJECT (VERSION 1.0)

WHAT THIS IS
This is the Android Studio source project for the first app version. It is not an APK yet.
It contains the quotation/invoice/receipt prototype inside a simple Android app shell.

FEATURES IN THIS FIRST BUILD
- Quotation, invoice and receipt screens
- USD currency
- Item rows and automatic subtotal/VAT/total calculations
- Customer and document fields
- Android share menu
- Android print / Save as PDF action
- App launcher icon

HOW TO BUILD AN APK
1. Transfer this ZIP to a computer with Android Studio installed.
2. Extract the ZIP.
3. In Android Studio choose Open and select the PowerSolutionsAndroid folder.
4. Allow Gradle sync to finish. Internet is needed the first time to download Android build tools.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the APK location, usually app/build/outputs/apk/debug/app-debug.apk.
7. Transfer that APK to your Android phone and open it to install. Android may ask you to allow installs from that file manager.

IMPORTANT
- This is a starter app, not a finished commercial accounting system.
- It currently does not permanently save customer records or create automatic sequential document numbers.
- The current prototype does not yet include the final approved company logo artwork. It uses a simple temporary lightning icon.
- Review all quotation totals and document details before sending to customers.


CLOUD BUILD FILE INCLUDED
The project now includes .github/workflows/build-apk.yml.
After uploading the project contents to a GitHub repository named PowerSolutionsACDC,
open the repository's Actions tab, choose "Build Power Solutions Android APK",
and select "Run workflow". When it finishes successfully, open the run and download
the artifact named "Power-Solutions-AC-DC-APK". Extract the ZIP artifact to get app-debug.apk.


Company management included on the home screen:
- Simon Dube — Chief Executive Officer (CEO)
- Petros Dube — Deputy Chief Executive Officer (Deputy CEO)
- Mike Dube — Technical, Operations & Finance Manager
  Electrical & Solar Systems Designer; Senior Technical Personnel; Operations and Project Management; Accounts Administration.

Company contacts configured:
- Main WhatsApp: 0779331564
- Mike Dube WhatsApp: 0784981579
- Petros Dube WhatsApp: 0771340158
- Calls: 0773955255
- Calls only: 0714472898
- Address: 12 Tilbury Road, Willowvale, Harare
- First Capital Bank, Gokwe Branch; Account name: Simon Dube; Account number: 52001557453
